from config import RETRIEVAL_TOP_K
from rag.embeddings import EmbeddingModel
from rag.vector_store import ChromaStore


def retrieve(query: str, top_k=RETRIEVAL_TOP_K, source_type=None):
    if not query or not query.strip():
        raise ValueError("Query cannot be empty.")

    embedder = EmbeddingModel()
    store = ChromaStore()

    if store.count() == 0:
        raise RuntimeError("Chroma is empty. Run `python ingest.py` first.")

    query_vector = embedder.embed_query(query.strip())
    raw = store.search(query_vector, top_k=top_k, source_type=source_type)

    results = []
    ids = raw.get("ids", [[]])[0]
    docs = raw.get("documents", [[]])[0]
    metas = raw.get("metadatas", [[]])[0]
    distances = raw.get("distances", [[]])[0]

    for doc_id, document, metadata, distance in zip(ids, docs, metas, distances):
        results.append({
            "id": doc_id,
            "text": document,
            "metadata": metadata,
            "distance": float(distance),
        })
    return results


def print_results(results):
    if not results:
        print("No matching chunks were returned.")
        return

    for rank, item in enumerate(results, start=1):
        meta = item["metadata"]
        location = f"page {meta['page']}" if "page" in meta else "text file"
        print("\n" + "=" * 80)
        print(f"Result {rank} | {meta.get('source_file')} | {location}")
        print(f"Cosine distance: {item['distance']:.4f} (lower is closer)")
        print("-" * 80)
        print(item["text"])


if __name__ == "__main__":
    user_query = input("Ask a question about your documents: ").strip()
    results = retrieve(user_query)
    print_results(results)
