# PDF + Text RAG with ChromaDB

A deliberately explicit local RAG project. It ingests PDF files and plain-text/Markdown files from two separate input folders, chunks the extracted text, creates embeddings with Sentence Transformers, stores vectors and source metadata in persistent ChromaDB, retrieves relevant chunks, and optionally generates a grounded answer using Groq.

## 1. Architecture

```text
pdf_documents/ -- pypdf page extraction --+
                                           |
                                           v
                                     text records
                                           |
text_documents/ -- UTF-8 parser ----------+
                                           |
                                           v
                                  cleaning + chunking
                                  (size 1200, overlap 200)
                                           |
                                           v
                              SentenceTransformer embeddings
                                           |
                                           v
                             ChromaDB persistent collection
                             chroma_db/knowledge_base
                                           |
User question -> same embedding model -> Chroma similarity search
                                           |
                                           v
                             top-k chunks + source metadata
                                           |
                           optional Groq grounded generation
                                           |
                                           v
                         answer with filename/page citations
```

Both file types use one collection so a question can search across PDFs and text files. Every stored chunk includes `source_type`, `source_file`, `source_path`, and `chunk_index`; PDF chunks also include a 1-based `page`.

## 2. Project structure

```text
pdf_text_chroma_rag/
├── pdf_documents/          # Put .pdf files here
├── text_documents/         # Put .txt and .md files here
├── rag/
│   ├── __init__.py
│   ├── parsers.py           # PDF and text parsing
│   ├── chunking.py          # Cleaning and overlapping chunks
│   ├── embeddings.py        # Sentence Transformer embeddings
│   └── vector_store.py      # Persistent ChromaDB operations
├── chroma_db/               # Created automatically; persistent database
├── config.py
├── ingest.py                # Parse -> chunk -> embed -> upsert
├── retrieve.py              # Query -> embed -> retrieve
├── answer.py                # Optional grounded LLM response
├── requirements.txt
├── .env.example
└── README.md
```

## 3. Requirements

- Python 3.10 or newer recommended.
- Internet access on first run to download the embedding model.
- For generated answers only: a Groq API key.
- This baseline extracts selectable PDF text. It does not OCR image-only/scanned PDFs.

## 4. Windows setup (PowerShell)

Open PowerShell in this project directory:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If PowerShell blocks activation, use Command Prompt instead:

```bat
.venv\Scripts\activate.bat
```

Add your files:
- PDF files -> `pdf_documents/`
- `.txt` or `.md` files -> `text_documents/`

Optional LLM setup:

```powershell
Copy-Item .env.example .env
```

Open `.env` and set `GROQ_API_KEY`. Do not commit or share this key.

## 5. Run ingestion

```powershell
python ingest.py
```

What happens, in order:

1. The program scans both input folders.
2. `pypdf` extracts text page by page from each PDF.
3. The text parser reads `.txt` and `.md` files as UTF-8.
4. The chunker normalizes whitespace and creates overlapping chunks.
5. Sentence Transformers converts every chunk into a numeric vector.
6. Chroma stores the chunk text, vector, and source metadata on disk.
7. When a file is re-ingested, its previous chunks are deleted first using its full source path (so identically named files in the two folders do not collide) to avoid stale chunks.

The embedding model is downloaded on first use and cached by Sentence Transformers. Chroma data remains in `chroma_db/` between runs.

## 6. Test retrieval without an LLM

```powershell
python retrieve.py
```

Enter a question. The program prints the top matching chunks, source file, page (for PDFs), and cosine distance.

Cosine distance is a ranking signal, not a guaranteed probability or factual-confidence score. Lower distance means a closer vector match. Do not treat a fixed distance threshold as universally reliable.

## 7. Generate a grounded answer (optional)

After setting `GROQ_API_KEY` in `.env`:

```powershell
python answer.py
```

The answer stage sends only retrieved chunks to the model and instructs it to:
- use only supplied context;
- say when the answer is not present;
- cite filenames and PDF page numbers;
- report conflicting source statements.

This reduces hallucinations but cannot mathematically guarantee zero hallucinations. Always inspect the retrieved chunks and citations for high-stakes use.

## 8. Important implementation details

### Why one collection?
A shared collection enables cross-format retrieval. `source_type` metadata lets you filter to `pdf` or `text` if needed. The `retrieve()` function accepts `source_type="pdf"` or `source_type="text"`.

### Why use the same embedding model?
Document vectors and question vectors must be generated in the same embedding space. This project loads one model name from `EMBEDDING_MODEL` for both paths.

### Why explicit embeddings?
The code computes embeddings itself and passes them to Chroma. Chroma is therefore a persistent vector store here, not a hidden embedding service. The same embedding code is used for indexing and querying.

### Why stable IDs and upsert?
Each chunk ID is a SHA-256 hash of its source path, page, chunk index, and text. Chroma `upsert` makes insertion repeatable. Before a file is indexed again, its old chunks are deleted by filename so edited/shortened files do not leave obsolete chunks behind.

### Scanned PDFs
If a PDF contains page images rather than selectable text, `pypdf` may return little or no text. This project warns and skips it; it does not silently pretend OCR occurred. Add an OCR stage (for example, Tesseract) if your source PDFs are scans.

### Tables, columns, diagrams
PDF text extraction is not perfect. Multi-column layouts, tables, equations, and diagrams may lose structure. Validate extracted text before trusting retrieval. For complex PDFs, consider layout-aware parsing or OCR/table extraction as a separate, testable pipeline stage.

## 9. Useful changes

- Chunk size and overlap: edit `CHUNK_SIZE` and `CHUNK_OVERLAP` in `config.py`.
- Retrieval count: edit `RETRIEVAL_TOP_K`.
- Embedding model: set `EMBEDDING_MODEL` in `.env`, then rebuild the collection if the model changes. Never mix vectors from different models in one collection.
- Filter by format in Python:

```python
from retrieve import retrieve

pdf_hits = retrieve("What is the refund policy?", source_type="pdf")
text_hits = retrieve("What is the refund policy?", source_type="text")
```

If you change the embedding model, use a fresh Chroma directory or delete/rebuild the existing collection so vectors from different embedding spaces are not mixed.

## 10. Troubleshooting

- `No files found`: check extensions and folder names.
- `Chroma is empty`: run `python ingest.py` successfully first.
- `No extractable text`: likely a scanned PDF or a PDF with unusual text encoding/layout.
- Model download errors: check internet access and Hugging Face availability.
- Out of memory: lower `EMBEDDING_BATCH_SIZE` in `config.py` and/or use a smaller embedding model.
- Groq authentication error: verify `GROQ_API_KEY` in `.env`.
- Changed file not reflected: rerun `python ingest.py`; the file's old chunks are replaced.

## 11. Data safety

The Chroma database is stored locally in `chroma_db/`. Treat the source files and database as sensitive if they contain private information. Do not upload the database or API key to a public repository.
