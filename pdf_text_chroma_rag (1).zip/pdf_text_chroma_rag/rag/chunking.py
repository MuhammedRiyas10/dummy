import re
from config import CHUNK_SIZE, CHUNK_OVERLAP


def clean_text(text: str) -> str:
    # Keep paragraph boundaries while normalizing excessive whitespace.
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def split_into_chunks(text: str, chunk_size=CHUNK_SIZE, overlap=CHUNK_OVERLAP):
    """Split text into overlapping character windows, preferring a nearby boundary."""
    if chunk_size <= 0:
        raise ValueError("chunk_size must be greater than zero")
    if overlap < 0 or overlap >= chunk_size:
        raise ValueError("overlap must be >= 0 and smaller than chunk_size")

    text = clean_text(text)
    if not text:
        return []

    chunks = []
    start = 0
    text_length = len(text)

    while start < text_length:
        end = min(start + chunk_size, text_length)

        if end < text_length:
            # Prefer a paragraph/newline/sentence/space boundary near the end.
            search_start = start + int(chunk_size * 0.65)
            candidates = [
                text.rfind("\n\n", search_start, end),
                text.rfind("\n", search_start, end),
                text.rfind(". ", search_start, end),
                text.rfind(" ", search_start, end),
            ]
            boundary = max(candidates)
            if boundary > start:
                end = boundary + (2 if text[boundary:boundary + 2] == ". " else 1)

        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)

        if end >= text_length:
            break
        next_start = max(start + 1, end - overlap)
        start = next_start

    return chunks


def chunk_records(records):
    """Convert parser records into chunk records while preserving source metadata."""
    output = []
    for record in records:
        for chunk_index, chunk in enumerate(split_into_chunks(record["text"])):
            item = {
                "text": chunk,
                "source_type": record["source_type"],
                "source_file": record["source_file"],
                "source_path": record["source_path"],
                "chunk_index": chunk_index,
            }
            if "page" in record:
                item["page"] = record["page"]
            output.append(item)
    return output
