from pathlib import Path
from typing import Iterator
from pypdf import PdfReader


def parse_pdf(path: Path) -> Iterator[dict]:
    """Yield one record per PDF page. Page numbers are 1-based."""
    reader = PdfReader(str(path))

    if reader.is_encrypted:
        try:
            reader.decrypt("")
        except Exception as exc:
            raise ValueError(f"PDF is encrypted and could not be opened: {path.name}") from exc

    for page_index, page in enumerate(reader.pages, start=1):
        text = page.extract_text() or ""
        text = text.strip()
        if text:
            yield {
                "text": text,
                "page": page_index,
                "source_type": "pdf",
                "source_file": path.name,
                "source_path": str(path.resolve()),
            }


def parse_text_file(path: Path) -> Iterator[dict]:
    """Read UTF-8 text/Markdown. Replace invalid byte sequences rather than crashing."""
    text = path.read_text(encoding="utf-8", errors="replace").strip()
    if text:
        yield {
            "text": text,
            "source_type": "text",
            "source_file": path.name,
            "source_path": str(path.resolve()),
        }
