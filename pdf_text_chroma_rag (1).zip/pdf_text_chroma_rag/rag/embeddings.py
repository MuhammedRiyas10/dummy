from sentence_transformers import SentenceTransformer
from config import EMBEDDING_MODEL_NAME


class EmbeddingModel:
    """One shared embedding model instance for indexing and query-time embeddings."""

    def __init__(self, model_name=EMBEDDING_MODEL_NAME):
        self.model = SentenceTransformer(model_name)

    def embed_documents(self, texts):
        vectors = self.model.encode(
            texts,
            batch_size=32,
            show_progress_bar=False,
            convert_to_numpy=True,
            normalize_embeddings=True,
        )
        return vectors.tolist()

    def embed_query(self, query):
        vector = self.model.encode(
            query,
            convert_to_numpy=True,
            normalize_embeddings=True,
        )
        return vector.tolist()
