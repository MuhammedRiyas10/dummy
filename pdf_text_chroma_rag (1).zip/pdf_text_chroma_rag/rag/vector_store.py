import chromadb
from config import CHROMA_DIR, COLLECTION_NAME


class ChromaStore:
    def __init__(self):
        self.client = chromadb.PersistentClient(path=str(CHROMA_DIR))
        # Embeddings are supplied explicitly. This avoids accidentally using a
        # different embedding function at query time.
        self.collection = self.client.get_or_create_collection(
            name=COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},
        )

    def delete_file_records(self, source_path: str):
        """Remove old chunks for this exact file path, preventing name collisions."""
        self.collection.delete(where={"source_path": source_path})

    def upsert_chunks(self, chunks, embeddings):
        if not chunks:
            return 0

        ids = [item["id"] for item in chunks]
        documents = [item["text"] for item in chunks]
        metadatas = [{k: v for k, v in item.items() if k not in ("id", "text")}
                     for item in chunks]

        self.collection.upsert(
            ids=ids,
            documents=documents,
            metadatas=metadatas,
            embeddings=embeddings,
        )
        return len(ids)

    def search(self, query_embedding, top_k=5, source_type=None):
        where = {"source_type": source_type} if source_type else None
        return self.collection.query(
            query_embeddings=[query_embedding],
            n_results=min(top_k, max(1, self.collection.count())),
            where=where,
            include=["documents", "metadatas", "distances"],
        )

    def count(self):
        return self.collection.count()
