from pathlib import Path
import os
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
PDF_DIR = BASE_DIR / "pdf_documents"
TEXT_DIR = BASE_DIR / "text_documents"
CHROMA_DIR = BASE_DIR / "chroma_db"

COLLECTION_NAME = "knowledge_base"
EMBEDDING_MODEL_NAME = os.getenv(
    "EMBEDDING_MODEL",
    "sentence-transformers/all-MiniLM-L6-v2",
)

# Character-based chunking is intentionally simple and inspectable.
CHUNK_SIZE = 1200
CHUNK_OVERLAP = 200
EMBEDDING_BATCH_SIZE = 32
RETRIEVAL_TOP_K = 5

for folder in (PDF_DIR, TEXT_DIR, CHROMA_DIR):
    folder.mkdir(parents=True, exist_ok=True)
