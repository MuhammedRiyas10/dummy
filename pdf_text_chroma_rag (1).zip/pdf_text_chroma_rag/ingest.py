import hashlib
from pathlib import Path

from config import PDF_DIR, TEXT_DIR, EMBEDDING_BATCH_SIZE
from rag.parsers import parse_pdf, parse_text_file
from rag.chunking import chunk_records
from rag.embeddings import EmbeddingModel
from rag.vector_store import ChromaStore


def make_chunk_id(item):
    # Stable ID: same file + page (if any) + chunk index + text.
    identity = "|".join([
        item["source_path"],
        str(item.get("page", "")),
        str(item["chunk_index"]),
        item["text"],
    ])
    return hashlib.sha256(identity.encode("utf-8")).hexdigest()


def discover_files():
    pdfs = sorted(PDF_DIR.glob("*.pdf"))
    text_files = sorted(
        list(TEXT_DIR.glob("*.txt")) + list(TEXT_DIR.glob("*.md"))
    )
    return [(path, "pdf") for path in pdfs] + [
        (path, "text") for path in text_files
    ]


def parse_file(path, file_type):
    if file_type == "pdf":
        return list(parse_pdf(path))
    return list(parse_text_file(path))


def main():
    files = discover_files()
    if not files:
        print("No files found. Add PDFs to pdf_documents/ and .txt/.md files to text_documents/.")
        return

    print(f"Found {len(files)} file(s). Loading embedding model...")
    embedder = EmbeddingModel()
    store = ChromaStore()

    total_chunks = 0
    for path, file_type in files:
        print(f"\nParsing: {path.name}")
        try:
            parsed_records = parse_file(path, file_type)
            if not parsed_records:
                print("  WARNING: No extractable text found; skipped.")
                if file_type == "pdf":
                    print("  This may be a scanned/image-only PDF. OCR is not enabled in this version.")
                continue

            chunks = chunk_records(parsed_records)
            for item in chunks:
                item["id"] = make_chunk_id(item)

            # Replacing the file's old chunks makes re-indexing safe.
            store.delete_file_records(str(path.resolve()))

            texts = [item["text"] for item in chunks]
            inserted = 0
            for start in range(0, len(chunks), EMBEDDING_BATCH_SIZE):
                batch = chunks[start:start + EMBEDDING_BATCH_SIZE]
                batch_texts = texts[start:start + EMBEDDING_BATCH_SIZE]
                vectors = embedder.embed_documents(batch_texts)
                inserted += store.upsert_chunks(batch, vectors)

            total_chunks += inserted
            print(f"  Extracted records: {len(parsed_records)}")
            print(f"  Created/stored chunks: {inserted}")
        except Exception as exc:
            print(f"  ERROR processing {path.name}: {type(exc).__name__}: {exc}")

    print(f"\nIngestion finished. This run stored {total_chunks} chunks.")
    print(f"Total chunks currently in Chroma: {store.count()}")


if __name__ == "__main__":
    main()
