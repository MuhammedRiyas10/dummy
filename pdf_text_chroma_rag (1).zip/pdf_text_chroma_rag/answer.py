import os
from groq import Groq
from dotenv import load_dotenv

from retrieve import retrieve

load_dotenv()

SYSTEM_PROMPT = """You are a document-grounded question-answering assistant.

Rules:
1. Answer using ONLY the supplied CONTEXT.
2. Do not use outside knowledge to fill gaps.
3. If the context does not contain the answer, say:
   "I could not find that information in the provided documents."
4. Do not invent names, dates, figures, definitions, or explanations.
5. Cite each factual claim using the source labels provided, for example [file: handbook.pdf, page: 4].
6. If sources disagree, clearly report the disagreement and cite both.
7. Distinguish what the documents explicitly state from any cautious inference.
"""


def build_context(results):
    blocks = []
    for result in results:
        meta = result["metadata"]
        label = f"file: {meta.get('source_file', 'unknown')}"
        if "page" in meta:
            label += f", page: {meta['page']}"
        blocks.append(f"[SOURCE: {label}]\n{result['text']}")
    return "\n\n---\n\n".join(blocks)


def answer_question(question, top_k=5):
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        raise RuntimeError("GROQ_API_KEY is missing. Add it to your .env file.")

    results = retrieve(question, top_k=top_k)
    if not results:
        return "I could not find that information in the provided documents.", []

    context = build_context(results)
    client = Groq(api_key=api_key)
    response = client.chat.completions.create(
        model=os.getenv("GROQ_MODEL", "openai/gpt-oss-120b"),
        temperature=0,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "user",
                "content": (
                    f"QUESTION:\n{question}\n\n"
                    f"CONTEXT:\n{context}\n\n"
                    "Answer the question using only the context and include source citations."
                ),
            },
        ],
    )
    return response.choices[0].message.content, results


if __name__ == "__main__":
    question = input("Ask your documents: ").strip()
    answer, sources = answer_question(question)
    print("\nANSWER\n" + answer)
    print("\nRETRIEVED SOURCES")
    for source in sources:
        meta = source["metadata"]
        print(f"- {meta.get('source_file')} | page={meta.get('page', 'N/A')} | distance={source['distance']:.4f}")
